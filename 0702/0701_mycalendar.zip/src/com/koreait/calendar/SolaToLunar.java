package com.koreait.calendar;

import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class SolaToLunar {

	public static ArrayList<LunarDate> solaToLunar(int year, int month) {
		
		ArrayList<LunarDate> lunarList = new ArrayList<>();
		String urlAddr = "";
		
		for (int i = 1; i <= 1; i++) {
			
			urlAddr = 
				String.format("https://astro.kasi.re.kr/life/pageView/5?search_year=%04d&search_month=%02d", year, i);
//			System.out.println(urlAddr);
			
//			Jsoup 라이브러리를 사용해서 클롤링한 정보가 기억될 객체를 선언한다.
			Document doc = null;
			try {
//				Jsoup 라이브러리의 connect() 메소드로 크롤링할 주소에 접속하고 get() 메소드로 사이트의 내용을
//				읽어온다.
				doc = Jsoup.connect(urlAddr).get();
				System.out.println(doc);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
		return null;
		
	}
	
	
}
