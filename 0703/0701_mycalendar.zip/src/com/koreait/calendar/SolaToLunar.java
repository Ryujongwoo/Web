package com.koreait.calendar;

import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class SolaToLunar {

	public static ArrayList<LunarDate> solaToLunar(int year, int month) {
		
		ArrayList<LunarDate> lunarList = new ArrayList<>();
		String urlAddr = "";
		
//		양력, 음력 날짜를 크롤링한다.
		for (int i = 1; i <= 12; i++) {
			
			urlAddr = 
				String.format("https://astro.kasi.re.kr/life/pageView/5?search_year=%04d&search_month=%02d", year, i);
//			System.out.println(urlAddr);
			
//			Jsoup 라이브러리를 사용해서 크롤링한 정보가 기억될 객체를 선언한다.
			Document html = null;
			try {
//				Jsoup 라이브러리의 connect() 메소드로 크롤링할 주소에 접속하고 get() 메소드로 사이트의 내용을
//				읽어온다.
				html = Jsoup.connect(urlAddr).get();
//				System.out.println(doc);
				
//				Elements 객체는 크롤링한 텍스트에서 select() 메소드로 지정한 선택자에 해당되는 노드들을
//				기억한다. => org.jsoup.select.Elements를 import 한다.
				Elements tr = html.select("#cont_skip table > tbody > tr");
//				System.out.println(elements);
				
				for (Element element : tr) {
					Elements td = element.select("td");
//					System.out.println(td);
//					System.out.println(td.get(0).text()); // 양력 날짜
//					System.out.println(td.get(1).text()); // 음력 날짜
//					System.out.println(td.get(2).text()); // 음력 날짜를 60 갑자로 표현한 날짜
					
					String sola = td.get(0).text();
					String lunar = td.get(1).text();
					
					LunarDate lunarDate = new LunarDate();
					lunarDate.setYear(Integer.parseInt(sola.split("-")[0]));
					lunarDate.setMonth(Integer.parseInt(sola.split("-")[1]));
					lunarDate.setDay(Integer.parseInt(sola.split("-")[2].split(" ")[0]));
					lunarDate.setYearLunar(Integer.parseInt(lunar.split("-")[0]));
					lunarDate.setMonthLunar(Integer.parseInt(lunar.split("-")[1]));
					lunarDate.setDayLunar(Integer.parseInt(lunar.split("-")[2].split(" ")[0]));
					lunarDate.setLunarFlag(lunar.length() > 10 ? true : false);
//					System.out.println(lunarDate);
					
					lunarList.add(lunarDate);
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
//		공휴일을 처리한다.
		for (int i = 0; i < lunarList.size(); i++) {
			
//			!lunarList.get(i).isLunarFlag() => 윤달이 아니면, 평달 이면
			if (!lunarList.get(i).isLunarFlag() && lunarList.get(i).getMonthLunar() == 1 && 
					lunarList.get(i).getDayLunar() == 1) {
				lunarList.get(i - 1).setLunar("<br><span>설날연휴</span>");
				lunarList.get(i).setLunar("<br><span>설날</span>");
				lunarList.get(i + 1).setLunar("<br><span>설날연휴</span>");
			} else if (!lunarList.get(i).isLunarFlag() && lunarList.get(i).getMonthLunar() == 4 && 
					lunarList.get(i).getDayLunar() == 8) {
				lunarList.get(i).setLunar("<br><span>석가탄신일</span>");
			} else if (!lunarList.get(i).isLunarFlag() && lunarList.get(i).getMonthLunar() == 8 && 
					lunarList.get(i).getDayLunar() == 15) {
				lunarList.get(i - 1).setLunar("<br><span>추석연휴</span>");
				lunarList.get(i).setLunar("<br><span>추석</span>");
				lunarList.get(i + 1).setLunar("<br><span>추석연휴</span>");
			} else if (lunarList.get(i).getMonth() == 1 && lunarList.get(i).getDay() == 1) {
				lunarList.get(i).setLunar("<br><span>신정</span>");
			} else if (lunarList.get(i).getMonth() == 3 && lunarList.get(i).getDay() == 1) {
				lunarList.get(i).setLunar("<br><span>삼일절</span>");
			} else if (lunarList.get(i).getMonth() == 5 && lunarList.get(i).getDay() == 1) {
				lunarList.get(i).setLunar("<br><span>근로자의날</span>");
			} else if (lunarList.get(i).getMonth() == 5 && lunarList.get(i).getDay() == 5) {
				lunarList.get(i).setLunar("<br><span>어린이날</span>");
			} else if (lunarList.get(i).getMonth() == 6 && lunarList.get(i).getDay() == 6) {
				lunarList.get(i).setLunar("<br><span>현충일</span>");
			} else if (lunarList.get(i).getMonth() == 8 && lunarList.get(i).getDay() == 15) {
				lunarList.get(i).setLunar("<br><span>광복절</span>");
			} else if (lunarList.get(i).getMonth() == 10 && lunarList.get(i).getDay() == 3) {
				lunarList.get(i).setLunar("<br><span>개천절</span>");
			} else if (lunarList.get(i).getMonth() == 10 && lunarList.get(i).getDay() == 9) {
				lunarList.get(i).setLunar("<br><span>한글날</span>");
			} else if (lunarList.get(i).getMonth() == 12 && lunarList.get(i).getDay() == 25) {
				lunarList.get(i).setLunar("<br><span>크리스마스</span>");
			}
			
//			어린이날 대체공휴일 처리
			if (lunarList.get(i).getMonth() == 5 && lunarList.get(i).getDay() == 6) {
				if (MyCalendar.weekDay(year, 5, 5) == 0) {
					lunarList.get(i).setLunar("<br><span>대체공휴일</span>");
				}
			} 
			if (lunarList.get(i).getMonth() == 5 && lunarList.get(i).getDay() == 7) {
				if (MyCalendar.weekDay(year, 5, 5) == 6) {
					lunarList.get(i).setLunar("<br><span>대체공휴일</span>");
				}
			} 
			
//			설날 연휴 대체공휴일 처리
			if(!lunarList.get(i).isLunarFlag() && lunarList.get(i).getMonthLunar() == 1 && lunarList.get(i).getDayLunar() == 1) {
				if(MyCalendar.weekDay(year, lunarList.get(i - 1).getMonth(), lunarList.get(i - 1).getDay()) == 4) {
					lunarList.get(i + 3).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, lunarList.get(i - 1).getMonth(), lunarList.get(i - 1).getDay()) == 5) {
					lunarList.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, lunarList.get(i - 1).getMonth(), lunarList.get(i - 1).getDay()) == 6) {
					lunarList.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, lunarList.get(i - 1).getMonth(), lunarList.get(i - 1).getDay()) == 0) {
					lunarList.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
			}
			
//			추석 연휴 대체공휴일 처리
			if(!lunarList.get(i).isLunarFlag() && lunarList.get(i).getMonthLunar() == 8 && lunarList.get(i).getDayLunar() == 15) {
				if(MyCalendar.weekDay(year, lunarList.get(i - 1).getMonth(), lunarList.get(i - 1).getDay()) == 4) {
					lunarList.get(i + 3).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, lunarList.get(i - 1).getMonth(), lunarList.get(i - 1).getDay()) == 5) {
					lunarList.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, lunarList.get(i - 1).getMonth(), lunarList.get(i - 1).getDay()) == 6) {
					lunarList.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
				if(MyCalendar.weekDay(year, lunarList.get(i - 1).getMonth(), lunarList.get(i - 1).getDay()) == 0) {
					lunarList.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
//				추석 연휴에 개천절이 끼어있는 경우
				if((lunarList.get(i - 1).getDay() == 3 || lunarList.get(i).getDay() == 3 || lunarList.get(i + 1).getDay() == 3) &&
						MyCalendar.weekDay(year, month, 3) != 4) {
					lunarList.get(i + 2).setLunar("<br><span>대체공휴일</span>");
				}
			}
			
		}
		
		for (int i = 0; i < lunarList.size(); i++) {
			System.out.println(lunarList.get(i));
		}
		
//		크롤링한 데이터에서 달력 출력에 필요한 달의 공휴일 정보만 리턴시킨다.
		ArrayList<LunarDate> list = new ArrayList<>();
		for (int i = 0; i < lunarList.size(); i++) {
			if (lunarList.get(i).getMonth() == month) {
				list.add(lunarList.get(i));
			}
		}
		
		return list;
		
	}
	
	
}








